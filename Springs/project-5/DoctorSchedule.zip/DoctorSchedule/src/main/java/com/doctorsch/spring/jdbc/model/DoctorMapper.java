package com.doctorsch.spring.jdbc.model;

public class DoctorMapper {

}
