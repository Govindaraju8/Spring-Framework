package com.govind.spring.jdbc.dao;

import com.govind.spring.jdbc.model.User;

public interface UserDAO {
	boolean createUser(User us);

}
